# Upstox Watchlist Automation

Chrome Extension (Manifest V3) for adding or removing up to 200 NSE EQ stocks from an existing Upstox watchlist using the visible Upstox web UI.

## Current version — v2.3.1
**Release:** v2.3.1  
**Update scope:** Requested maintenance-only update. Existing automation flow and functionality are preserved except for the explicitly listed corrections below.

### v2.3.1 updates
- Extension/tool title changed to **Upstox Watchlist Automation**.
- Manifest version updated from **2.3.0** to **2.3.1**.
- Popup page title updated to **Upstox Watchlist Automation v2.3.1**.
- Watchlist name now explicitly supports names such as `1`, `2`, `3`, `watchlist1`, `watchlist2`, and other names containing **letters, numbers, and spaces only**.
- Watchlist names containing special characters are rejected before a run starts.
- Details/About content now explicitly documents the complete supported watchlist-name rule.
- Details/About content now explicitly documents loading a stock list from Notepad/a TXT/CSV/TSV file using **Browse file** followed by **Load**.
- Details/About content now documents the supported stock-list input separators: **one-per-line, comma, semicolon, and tab**.
- The existing **200-stock limit**, Add/Remove modes, progress/logging, Stop, Copy report, CSV download, Retry failed, exact NSE EQ matching, and visible UI automation remain unchanged.

## Version history

### v2.3.1
- Maintenance update described above.
- No unrelated functionality or workflow changes were introduced.

### v2.3.0
- Existing v2.3 package baseline used for this maintenance update.
- Existing watchlist selection, stock-list parsing, Add/Remove flow, reports, retry, and file loading behavior retained.

### v2.2.1 — Fixed v2.2
- Remove mode targets `[data-id="removeScripSearch"]`.
- Remove is performed only when the matching NSE EQ result visibly shows **Remove**.
- BSE results are ignored.
- Removed the 5-reference-stock section.
- Browse and Load buttons received colored styling.
- Product/extension name changed to Upstox Platform Watchlist Change Automator.

### v2.2.0
- Restored the earlier 420px popup size.
- Added Add / Remove operation modes.
- Added colored non-official extension icons.
- Remove mode searches exact stock name/symbol + NSE EQ and acts on the visible watchlist action.

### v2.1.0
- Restyled the compact popup UI.
- Added Browse file + Load for TXT/CSV/TSV lists.
- Added up-to-200 file loading.
- CSV reports include the watchlist name and operation.
- Slightly reduced fixed delays while retaining UI wait safeguards.

### v1.0.1
- Added automatic content-script connection/injection recovery to resolve the browser connection error when the Upstox tab had no receiving content script.

### v1.0.0
- Initial Manifest V3 implementation.
- Watchlist name supplied at runtime.
- Up to 200 stocks per execution.
- Newline/comma/semicolon/tab parsing.
- Exact NSE EQ matching and first matching search result.
- Add flow, progress, live log, Stop, CSV report, clipboard report, retry, and failure-safe continuation.

## Supported watchlist names
Enter the **exact visible target watchlist name**. Supported characters are:
- Letters: `A-Z` / `a-z`
- Numbers: `0-9`
- Spaces between words

Examples: `1`, `2`, `3`, `watchlist1`, `watchlist2`, `My Watchlist 1`.  
Special characters such as `@`, `#`, `/`, `\`, `:`, `-`, `_`, `.` and similar punctuation are not supported by the input validation.

## Stock-list input methods
Paste up to **200 stock names/symbols** into the Stocks box. Input supports:
- One stock per line
- Comma-separated values
- Semicolon-separated values
- Tab-separated values

### Load from Notepad / file
1. Prepare the stock list in Notepad (or another text editor) and save it as `.txt`, `.csv`, or `.tsv`.
2. Click **Browse file** in the extension.
3. Select the prepared file.
4. Click **Load**.
5. The loaded stock names/symbols are placed into the Stocks box. If the file contains more than 200 entries, only the first 200 are loaded.

## How it works
1. Stay logged in to Upstox.
2. Create the target watchlist first.
3. Enter its exact visible name using supported characters only.
4. Paste up to 200 stock names/symbols from Notepad, or use **Browse file** and then **Load** for a TXT/CSV/TSV list.
5. Choose **Add** or **Remove**.
6. Click **Start**.

The automation waits for the search UI, requires an exact stock name/symbol plus `NSE EQ`, and then uses the appropriate visible Add/Remove action. It never clicks Buy/Sell and does not require credentials or API keys.

## Existing functionality retained
- Add and Remove modes.
- Exact visible watchlist selection.
- Exact NSE EQ matching.
- First matching visible result.
- Up to 200 unique stock entries.
- Stop processing.
- Progress and live log.
- Copy report.
- CSV report download.
- Retry failed / not-found items.
- Browse + Load for TXT/CSV/TSV files.
- No Upstox credentials or API keys.
- No Buy/Sell action.

## Installation
1. Extract the ZIP.
2. Open `chrome://extensions`.
3. Enable **Developer mode**.
4. Select **Load unpacked** and choose the extracted extension folder.
5. Open the logged-in Upstox web app, enter the watchlist name and stock list, choose Add/Remove, then Start.

## Important UI note
The extension uses exact visible watchlist text and the supplied Upstox search UI. If a future Upstox UI changes the watchlist selector or search DOM, a small DOM-specific selector adjustment may be required.

Upstox uses a virtualized watchlist list, so only currently rendered rows are available in the DOM. In Add mode, **Already exists** is reported when the matching row is currently rendered; otherwise the extension uses the Add action. In Remove mode, **Not in watchlist** is reported when the exact NSE EQ result exists but its visible action is not **Remove**.

## Developer
**Developer:** Mohan Seerangan  
**Contact:** mohangbox11@gmail.com | mohangbox@gmail.com
