chrome.runtime.onInstalled.addListener(()=>chrome.storage.local.set({wsa_state:{running:false,results:[],processed:0,total:0,log:"",lastTabId:null}}));

async function ensureContentScript(tabId){
  try{const pong=await chrome.tabs.sendMessage(tabId,{type:"PING"});if(pong?.ready)return;}catch(e){}
  await chrome.scripting.executeScript({target:{tabId},files:["content/upstox.js"]});
  const end=Date.now()+4000;
  while(Date.now()<end){try{const pong=await chrome.tabs.sendMessage(tabId,{type:"PING"});if(pong?.ready)return;}catch(e){} await new Promise(r=>setTimeout(r,100));}
  throw new Error("Could not connect to the Upstox page. Refresh the Upstox tab and try again.");
}

chrome.runtime.onMessage.addListener((m,_,sendResponse)=>{
 if(m?.type==='START_RUN'){(async()=>{try{await ensureContentScript(m.tabId);await chrome.tabs.sendMessage(m.tabId,{type:"START_RUN",watchlistName:m.watchlistName,stocks:m.stocks,operation:m.operation||'add'});sendResponse({ok:true});}catch(e){sendResponse({ok:false,error:e.message});}})();return true;}
 if(m?.type==='STOP_RUN'&&m.tabId)chrome.tabs.sendMessage(m.tabId,{type:'STOP_RUN'}).catch(()=>{});
});
