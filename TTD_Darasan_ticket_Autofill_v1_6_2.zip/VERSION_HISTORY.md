# Version History — TTD Darasan ticket Autofill

## 1.6.0 — 2026-09-14

### UI / Editing
- Pilgrim section title changed to `Pilgrim Details (N)`.
- Applied justified text alignment to content-oriented UI text.
- Enforced one active Edit form per section so switching to another record collapses the previous editor; repeated clicks on the same record do not create additional editor instances.

### Documentation
- Updated README, TOOLS, CHANGELOG, and version history for v1.6.0.
- Existing functionality and data-flow contracts remain unchanged.


## 1.4.0 — 2026-09-14

### Data transfer
- Export uses the exact flat TXT structure requested:
  `Group Name | Name | Age | Gender | Photo ID Proof | Photo Id Number | Email Address | City | State | Country | Pincode | Gotharam |`
- No `Header:` prefix, `Details N:` prefixes, or structural marker text are written to the file.
- Import validates the exact header and maps all twelve columns positionally.
- Imported matching Pilgrim Tickets are updated by Group Name + Name.
- Imported matching Accommodation Details are updated by Group Name + Email Address.
- New imported records append to the existing lists.

### Editing / UX
- Repeated clicks on one record's Edit button no longer create repeated editors; one editor instance is maintained for that record.
- About & Usage content updated for the complete current workflow.

### Preserved functionality
- Group-first selection and group-linked child records.
- Group checkbox selection does not autofill.
- `Fill Current Page` remains the sole autofill trigger.
- Delete, drag-and-drop, fixed-width popup, TXT-only import, and existing TTD field mappings are preserved.

## 1.3.0 — 2026-09-14
- Fixed deletion across all three sections.
- Removed automatic autofill on group checkbox changes.
- Removed Clear Selection.
- Fixed popup width at 430px.
- Added TXT Export/Import.

## 1.2.0 — 2026-09-14
- Introduced Group Names as the parent selection layer.
- Added `groupId` relationships between Groups, Pilgrim Tickets, and Accommodation Details.
- Added group assignment fields and group-centric selection.

## 1.1.0 — 2026-09-14
- Added Group Name management and child record tagging.
- New records append to the bottom.
- Accommodation card title changed to Email Address.

## 1.0.1 — 2026-09-14
- Added active-page content-script injection fallback.

## 1.0.0 — 2026-09-14
- Initial Manifest V3 release.


### 1.6.0 — 2026-09-14
Accommodation General Details autofill reliability update. Field targets are re-resolved after each value change so dynamic page rerenders do not invalidate later field references.
