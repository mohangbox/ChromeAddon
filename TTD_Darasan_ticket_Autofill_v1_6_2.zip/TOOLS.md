# Tools / Technical Design — TTD Darasan ticket Autofill v1.6.0

## Extension architecture
- Chrome Manifest V3.
- Popup UI: `popup/popup.html`, `popup/popup.css`, `popup/popup.js`.
- TTD page integration: `content/content.js`.
- Persistence: `chrome.storage.local`.
- Runtime page injection fallback: `chrome.scripting.executeScript` with `activeTab` and `scripting` permissions.

## Data model

```text
Groups
  id: string (primary key)
  name: string
  selected: boolean

Pilgrim_Tickets
  id: string (primary key)
  groupId: string (foreign key -> Groups.id)
  name: string
  age: string
  gender: string
  photoIdType: string
  idProofNumber: string

Accommodation_Details
  id: string (primary key)
  groupId: string (foreign key -> Groups.id)
  email: string
  city: string
  state: string
  country: string
  pincode: string
  gotharam: string
```

## Selection and data flow
1. Only Group records expose checkboxes.
2. A selected group is the parent filter for both child collections.
3. `selectedRecords()` resolves selected Groups and returns all Pilgrim/Accommodation records whose `groupId` matches.
4. Group selection sends the resolved child records to the content script and attempts an active-page pre-fill.
5. `Fill Current Page` uses exactly the same group-derived state.
6. Group checkbox changes update only `Groups.selected`; there is no Clear Selection control.
7. Individual child records have no selection state in the UI.

## CRUD behavior
- Create: `push()` appends new Groups, Pilgrims, and Accommodations to the bottom.
- Update: edits the existing object while preserving its `id` and `groupId` unless explicitly changed.
- Delete child: removes only the selected child object.
- Delete group: requires confirmation when children exist; children are reassigned to a remaining group.
- Reorder: HTML5 drag-and-drop updates the corresponding array order.

## Counter convention
- Group section title: `Group Names (N)` where `N` is the current number of Groups; empty state is `0`.
- Pilgrim title: `Pilgrim Details (N)`.
- Accommodation title: `Accommodation Details(N)`.

## Content-script field mapping
### Pilgrim
- `fname`
- `age`
- `gender`
- `photoIdType`
- `idProofNumber`

### Accommodation
- `emailId`
- `city`
- `state`
- `country`
- `pincode`
- Gotharam: label/name fallback containing `gotharam`.

## UX / accessibility
- Group cards expose checkbox labels through `aria-label`.
- Lists use `role="list"` / `role="listitem"`.
- Status messages use `aria-live="polite"`.
- Buttons have accessible labels where the visible text is not sufficient.
- Selected groups receive a visible selected state.
- Layout uses responsive CSS and `dir="auto"` for user-entered names.
- User-visible strings are centralized in `I18N.en` so additional locale dictionaries can be added without changing data flow.

## Security / privacy
- Data remains in `chrome.storage.local`.
- The extension does not handle login credentials, CAPTCHA, payment, or booking submission.
- The active-page fallback runs only after the user invokes the extension operation.

## Validation
- `node --check popup/popup.js`
- `node --check content/content.js`
- Manifest JSON parsing.
- ZIP structure verification.


## v1.6.0 Tooling Notes
- Pilgrim section title is rendered as `Pilgrim Details (N)` in both initial HTML and runtime rendering.
- Content paragraphs, hints, metadata, and record names use justified text alignment for consistent visual presentation.
- `openUniqueEditor()` enforces one active editor per section: when another record is edited, the previous editor is removed before the new editor is shown; clicking the same Edit action repeatedly reuses the existing editor.
- No existing data model, selection flow, autofill trigger, CRUD behavior, ordering, import/export mapping, or TTD integration contract is changed.

## v1.4.0 Tooling Notes
- Export writes exactly one fixed header row followed by flat pipe-delimited data rows:
  `Group Name | Name | Age | Gender | Photo ID Proof | Photo Id Number | Email Address | City | State | Country | Pincode | Gotharam |`
- Export preserves blank child fields rather than adding structural labels or record-number prefixes.
- Import validates the fixed header and parses the twelve data columns by position, preventing field shifts such as City becoming the Accommodation record title.
- Import is an upsert by Group Name + Pilgrim Name for Pilgrim Tickets and Group Name + Email Address for Accommodation Details; matching records are updated and new records are appended.
- Repeated Edit clicks for the same record resolve to one editor instance identified by the record id.
- Group checkbox changes remain local selection state only; autofill remains exclusively under `Fill Current Page`.
- Popup width remains fixed at 430px across empty and populated states.


## v1.6.0 update
Accommodation General Details uses fresh DOM queries per field update because the TTD page can replace controlled input elements during validation/state updates. This preserves values across component rerenders without changing the existing Pilgrim autofill flow.
