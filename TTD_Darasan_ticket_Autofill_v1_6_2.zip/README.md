# TTD Darasan ticket Autofill

Version: **1.6.0**

A Chrome Manifest V3 extension that locally manages TTD Darshan Pilgrim Ticket and Accommodation details and autofills the currently active TTD form after the user has logged in normally.

## 1. Install

1. Open Chrome and go to Extensions → Manage Extensions.
2. Enable Developer mode.
3. Select **Load unpacked**.
4. Select the extracted `ttd-addon` folder.
5. Open the TTD website and log in normally.

## 2. Group-first workflow

The extension is now group-centric:

1. Create one or more Group Names.
2. Groups appear in the `Group Names (N)` section.
3. Only Group Name records have selection checkboxes.
4. Add Pilgrim Ticket records and assign each record to a Group Name.
5. Add Accommodation records and assign each record to a Group Name.
6. Select one or more Group Name checkboxes. This changes only the local selection state.
7. Click **Fill Current Page** to load the selected groups and autofill the active TTD form.

## 3. Group Selection

Only Group Name records have selection checkboxes. Checking or unchecking a group changes local selection state only and **does not autofill the TTD page**. Use **Fill Current Page** to start the autofill operation.

It does not select, unselect, delete, reorder, or modify Pilgrim Ticket or Accommodation records.

## 4. Record ordering

New records are appended to the bottom of their respective lists:

- Groups
- Pilgrim Tickets
- Accommodation Details

Existing drag-and-drop ordering remains available.

## 5. Group relationship

Each child record stores a `groupId` referencing its parent Group. Renaming a Group does not break its child records.

Deleting a non-empty Group displays a confirmation. Associated child records are moved to another existing Group rather than silently deleted. Deleting an individual child removes only that child.

## 6. Forms

### Pilgrim Ticket

- Group Name
- Name
- Age
- Gender
- Photo ID Proof
- Photo ID Number

New Pilgrim records default to the first-listed Group.

### Accommodation

- Group Name
- Email Address
- City
- State
- Country
- Pincode
- Gotharam

New Accommodation records default to the first-listed Group.

Accommodation card headers display the **Email Address**.

## 7. Autofill behavior

The extension maps the supplied TTD DOM fields as follows:

| Data | TTD field |
|---|---|
| Pilgrim Name | `fname` |
| Age | `age` |
| Gender | `gender` |
| Photo ID Proof | `photoIdType` |
| Photo ID Number | `idProofNumber` |
| Email | `emailId` |
| City | `city` |
| State | `state` |
| Country | `country` |
| Pincode | `pincode` |
| Gotharam | label/name fallback containing `gotharam` |

The extension fills visible dynamic rows in order and does not submit the booking.

## 8. Accessibility and localization

- Group selection checkboxes have accessible labels.
- Lists and records expose ARIA list semantics.
- Status messages use live-region feedback.
- Focus states are visible.
- User-entered names support direction-aware rendering with `dir="auto"`.
- User-visible strings are centralized in the popup localization dictionary for future locale expansion.
- Responsive layout accommodates variable text lengths.

## 9. Export / import data

Use **Export** to download all local groups and their tagged Pilgrim Ticket and Accommodation records as a human-readable `.txt` file. Use **Import** to load a `.txt` file from the local file picker. Non-TXT files are rejected. Import merges records by Group Name and avoids duplicate child records within the same group.

The exported TXT format is intentionally flat and fixed so it can be read, edited, and imported without additional markers:

`Group Name | Name | Age | Gender | Photo ID Proof | Photo Id Number | Email Address | City | State | Country | Pincode | Gotharam |`

Each following row contains the Group Name first, followed by the five Pilgrim Ticket fields and the six Accommodation fields. Blank fields are preserved. The same format is accepted by Import.

## 10. Privacy and security

- Data is stored locally in Chrome Storage.
- No credentials are collected.
- No CAPTCHA automation.
- No payment processing.
- No booking submission.

## 11. Current-page access fallback

If the content script is not already available on the active tab, the extension attempts runtime injection using the Chrome `scripting` API. Chrome-restricted pages such as `chrome://`, the Chrome Web Store, and browser PDF viewers cannot be modified by extensions in the normal way.

## 12. Production validation note

The TTD application uses dynamic/custom controls and may change its DOM. The supplied field names are implemented as the primary selectors, with custom dropdown handling and Gotharam fallback logic. A final live-site regression test should be performed against the currently deployed TTD form before Chrome Web Store publication.

## 13. Version control

See:
- `VERSION_HISTORY.md`
- `CHANGELOG.md`
- `TOOLS.md`


## v1.6.0 Updates
- Pilgrim Ticket section title now follows the requested `Pilgrim Details (N)` format.
- Textual content is presented with justified paragraph/content alignment for a consistent reading layout.
- Within each section, only one Edit form is active at a time; opening a different record collapses the previously open Edit form, while repeatedly selecting the same record does not create another editor.
- Existing Group selection, autofill, CRUD, ordering, Export/Import, fixed-width, accessibility, localization, and TTD field-mapping behavior remains unchanged.

## v1.4.0 Updates
- Export now uses the exact flat pipe-delimited TXT format specified for Group Name, Pilgrim Ticket fields, and Accommodation fields.
- Import now maps the flat TXT columns directly to the correct stored fields, including City, State, Country, Pincode, and Gotharam.
- Import performs group-aware upsert behavior: matching Pilgrim records are updated by Group Name + Name, and matching Accommodation records are updated by Group Name + Email Address; new records are appended.
- Repeated clicks on the same Edit action open only one editor for that record.
- About & Usage documentation reflects the complete current workflow, selection behavior, editing, ordering, and TXT transfer functions.


## v1.6.0 – Accommodation General Details reliability
The Accommodation autofill now re-queries the live General Details inputs after each field update so React-controlled/rerendered inputs receive Email Address, City, State, Country, Pincode, and Gotharam values reliably. The existing Pilgrim Details flow and all other functionality remain unchanged.
