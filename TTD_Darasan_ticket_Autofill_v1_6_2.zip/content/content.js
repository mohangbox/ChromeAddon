(() => {
  if (window.__TTD_AUTOFILL_LOADED__) return; window.__TTD_AUTOFILL_LOADED__=true;
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const visible=e=>!!(e&&e.getBoundingClientRect().width&&e.getBoundingClientRect().height);
  const inputs=(name)=>[...document.querySelectorAll(`input[name="${name}"]`)].filter(visible);
  const fire=e=>{e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));e.dispatchEvent(new Event('blur',{bubbles:true}))};
  function setInput(e,v){if(!e)return false;const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set;if(setter)setter.call(e,String(v));else e.value=String(v);fire(e);return true}
  async function clickOption(input,value){if(!input)return false;input.click();await sleep(100);const candidates=[...document.querySelectorAll('body *')].filter(visible).filter(x=>x.children.length===0);const wanted=candidates.find(x=>x.textContent.trim()===value);if(wanted){wanted.click();await sleep(80);return true}
    input.focus();input.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true}));input.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}));await sleep(80);return (input.value||'').trim()===value;
  }
  async function fillRow(i,p){const names=inputs('fname'),ages=inputs('age'),genders=inputs('gender'),ids=inputs('photoIdType'),nums=inputs('idProofNumber');if(!names[i]||!ages[i]||!genders[i]||!ids[i]||!nums[i])return false;setInput(names[i],p.name);setInput(ages[i],p.age);await clickOption(genders[i],p.gender);await clickOption(ids[i],p.photoIdType);if(nums[i].disabled){try{nums[i].disabled=false}catch{}}setInput(nums[i],p.idProofNumber);return true}
  async function fillPilgrims(ps){const count=Math.min(ps.length,inputs('fname').length);for(let i=0;i<count;i++){await fillRow(i,ps[i]);await sleep(120)}return count}
  function generalFields(name){return [...document.querySelectorAll(`input[name="${name}"]`)].filter(visible)}
  // Find the Gotharam input by scanning label elements whose text contains "Gotharam"
  // and returning the associated input (preceding sibling or nearby input in the same container).
  function gotharamFields(){
    // Strategy 1: look for an input whose immediately wrapping container has a label with "Gotharam" text
    const allLabels=[...document.querySelectorAll('label')].filter(visible);
    const gotharamLabel=allLabels.find(l=>/gotharam/i.test(l.textContent));
    if(gotharamLabel){
      // If label[for] is set, find by id
      if(gotharamLabel.htmlFor){const inp=document.getElementById(gotharamLabel.htmlFor);if(inp&&visible(inp))return[inp]}
      // Otherwise walk up to the container and find the nearest input
      const container=gotharamLabel.closest('div,p,td,li,section');
      if(container){const inp=container.querySelector('input');if(inp&&visible(inp))return[inp]}
      // Try next sibling or parent's input
      let node=gotharamLabel.nextElementSibling;while(node){if(node.tagName==='INPUT'&&visible(node))return[node];node=node.nextElementSibling}
    }
    // Strategy 2: find inputs by label attribute (older approach, kept as fallback)
    const byAttr=[...document.querySelectorAll('input')].filter(x=>visible(x)&&/gotharam/i.test((x.getAttribute('label')||'')+' '+(x.getAttribute('aria-label')||'')+' '+(x.name||'')));
    if(byAttr.length)return byAttr;
    // Strategy 3: find input whose placeholder contains gotharam
    const byPlaceholder=[...document.querySelectorAll('input')].filter(x=>visible(x)&&/gotharam/i.test(x.placeholder||''));
    return byPlaceholder;
  }
  function currentGeneralField(name,index=0){const fields=generalFields(name);return fields[index]||fields[0]||null}
  function currentGotharamField(){const fields=gotharamFields();return fields[0]||null}
  async function setGeneralField(name,value,index=0){
    const field=currentGeneralField(name,index);
    if(!field)return false;
    field.focus();
    setInput(field,value);
    await sleep(120);
    return true;
  }
  async function setGotharamField(value){
    // Gotharam is a single field in the General Details section — fill it exactly once.
    const field=currentGotharamField();
    if(!field)return false;
    field.focus();
    setInput(field,value);
    await sleep(120);
    return true;
  }
  async function fillAccommodation(ps, accommodations, groups){
    // 1. Fill all pilgrim rows first (name/age/gender/ID).
    const count=await fillPilgrims(ps);

    // 2. Determine the gotharam value from the first selected group name.
    //    The group name is filled into the Gotharam field once after all pilgrim rows.
    const gotharamValue=(Array.isArray(groups)&&groups.length)
      ? groups[0].name
      : ((Array.isArray(accommodations)&&accommodations[0]?.gotharam)||'');

    // 3. Fill the single General Details form (email, city, state, country, pincode).
    //    The TTD page has exactly one General Details block regardless of pilgrim count.
    //    Use the first accommodation record for email/city/state/country/pincode.
    const a=(Array.isArray(accommodations)&&accommodations[0])||null;
    if(a){
      await setGeneralField('emailId', a.email, 0);
      await setGeneralField('city',    a.city,   0);
      await setGeneralField('state',   a.state,  0);
      await setGeneralField('country', a.country,0);
      await setGeneralField('pincode', a.pincode,0);
    }

    // 4. Fill Gotharam field once with the selected group name.
    if(gotharamValue) await setGotharamField(gotharamValue);

    return count;
  }
  chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
    if(msg?.type!=='TTD_FILL')return;
    (async()=>{
      const isAccom=/Accommodation/i.test(document.body.innerText.slice(0,4000));
      // NOTE: popup.js sends the key as 'accommodations' (plural) — use that.
      const count=isAccom
        ? await fillAccommodation(msg.pilgrims||[], msg.accommodations||[], msg.groups||[])
        : await fillPilgrims(msg.pilgrims||[]);
      sendResponse({ok:count>0,message:`Filled ${count} pilgrim row(s). Please review all values before continuing.`});
    })().catch(e=>sendResponse({ok:false,message:'Autofill stopped: '+e.message}));
    return true;
  });
})();
