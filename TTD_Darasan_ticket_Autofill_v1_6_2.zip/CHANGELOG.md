# Changelog — TTD Darasan ticket Autofill

## [1.6.0] - 2026-09-14

### Added / Changed
- Updated the Pilgrim section title to `Pilgrim Details (N)`.
- Applied justified alignment to textual content areas for a consistent reading layout.
- Enforced a single active Edit form per section; opening a different record collapses the previous editor, and repeated clicks on the same record reuse the existing editor.
- Updated version, README, and technical tooling documentation.

### Preserved
- Group-first selection model and `groupId` relationships.
- Group checkbox selection without automatic autofill.
- `Fill Current Page` as the autofill action.
- CRUD, drag-and-drop ordering, fixed popup width, TXT-only import, exact TXT export format, and existing TTD field mappings.


## [1.4.0] - 2026-09-14

### Added / Changed
- Export format is now exactly the requested flat pipe-delimited TXT format with one fixed header row and data rows.
- Import parser now reads the fixed twelve-column format directly and preserves the correct field mapping.
- Import updates matching records using Group Name + Pilgrim Name for Pilgrim Tickets and Group Name + Email Address for Accommodation Details; unmatched records are added.
- Repeated clicks on the same Edit button now keep a single editor open for that record.
- About & Usage content has been refreshed for the current feature set and operating flow.
- Documentation and technical notes updated for v1.4.0.

### Preserved
- Group-first selection model.
- Group-linked `groupId` relationships.
- No child-record selection checkboxes.
- No automatic autofill on group checkbox changes.
- `Fill Current Page` as the autofill action.
- Fixed 430px popup width.
- TXT-only import.
- Append-to-bottom behavior for new records.
- Accommodation record title uses Email Address.

## [1.3.0] - 2026-09-14
- Fixed record delete actions across Groups, Pilgrim Tickets, and Accommodation Details.
- Group checkbox changes no longer autofill the TTD page.
- Removed Clear Selection.
- Stabilized popup width at 430px.
- Added TXT Export/Import.

## [1.2.0] - 2026-09-14
- Added Group-centric selection and `groupId` relationships.
- Added Group Names management and group assignment fields.
- Added accessibility/localization foundation.

## [1.1.0] - 2026-09-14
- Added Group Name assignment to Pilgrim and Accommodation records.
- Added Group management and append-to-bottom behavior.
- Changed Accommodation card title to Email Address.

## [1.0.1] - 2026-09-14
- Added active-page content-script injection fallback to resolve current-page access errors.

## [1.0.0] - 2026-09-14
- Initial Manifest V3 release.


## 1.6.0 — 2026-09-14
- Fixed Accommodation General Details autofill reliability for Email Address, City, State, Country, Pincode, and Gotharam.
- Re-queries live inputs after each update to support TTD page rerendering.
- Preserved all existing functionality and UI behavior.
