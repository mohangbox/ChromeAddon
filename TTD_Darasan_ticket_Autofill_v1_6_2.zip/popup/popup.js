const DEFAULT={groups:[],pilgrims:[],accommodations:[]};
const $=s=>document.querySelector(s);
const I18N={en:{
  groupSection:'Group Names', groupHint:'Select groups to prepare their associated ticket and accommodation records. Drag groups to change order. New groups are added at the bottom.',
  pilgrimHint:'Pilgrim records are managed through their Group Name. Drag records to change their fill order.',
  accomHint:'Accommodation records are managed through their Group Name. Drag records to change their order.',
  add:'+ Add', edit:'Edit', del:'Delete', save:'Save', cancel:'Cancel', fill:'Fill Current Page',
  exportData:'Export Data', importData:'Import Data', exportDone:'Data exported successfully.', importDone:'Data imported successfully.',
  groupDetails:'Group Details', groupName:'Group Name', pilgrimDetails:'Pilgrim Details', accommodationDetails:'Accommodation Details',
  noPilgrims:'No saved pilgrim details. Click + Add.', noAccom:'No saved accommodation details. Click + Add.',
  selectGroup:'Select group',
}};
const t=k=>I18N.en[k]||k;
let data=structuredClone(DEFAULT);
function uid(){return crypto.randomUUID()}
function save(){chrome.storage.local.set(data)}
function status(msg,ok=true){const e=$('#status');e.textContent=msg;e.className='status '+(ok?'ok':'err');setTimeout(()=>e.className='status',4500)}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function groupName(id){return data.groups.find(g=>g.id===id)?.name||''}
function ensureGroups(){
  if(!Array.isArray(data.groups))data.groups=[];
  data.groups=data.groups.map(g=>({...g,selected:!!g.selected}));
  // Enforce single selection: if none selected, pick first; if multiple selected, keep only the first selected one
  const selectedGroups=data.groups.filter(g=>g.selected);
  if(!selectedGroups.length && data.groups.length){data.groups[0].selected=true;}
  else if(selectedGroups.length>1){const firstSel=selectedGroups[0].id;data.groups.forEach(g=>{g.selected=g.id===firstSel;});}
  const first=data.groups[0]?.id||'';
  data.pilgrims=(Array.isArray(data.pilgrims)?data.pilgrims:[]).map(p=>({...p,groupId:p.groupId||data.groups.find(g=>g.name===p.groupName)?.id||first}));
  data.accommodations=(Array.isArray(data.accommodations)?data.accommodations:[]).map(a=>({...a,groupId:a.groupId||data.groups.find(g=>g.name===a.groupName)?.id||first}));
}
function groupOptions(selected){if(!data.groups.length)return '<option value="" selected disabled>No groups available — add a Group Name first</option>';return data.groups.map(g=>`<option value="${esc(g.id)}" ${g.id===selected?'selected':''}>${esc(g.name)}</option>`).join('')}
function selectedRecords(){
  const selectedIds=new Set(data.groups.filter(g=>g.selected).map(g=>g.id));
  return {
    groups:data.groups.filter(g=>selectedIds.has(g.id)),
    pilgrims:data.pilgrims.filter(p=>selectedIds.has(p.groupId)),
    accommodations:data.accommodations.filter(a=>selectedIds.has(a.groupId))
  };
}
async function fillActivePage(records, silent=false){
  try{
    const [tab]=await chrome.tabs.query({active:true,lastFocusedWindow:true});
    if(!tab?.id)throw new Error('No active tab found.');
    let r;
    try{r=await chrome.tabs.sendMessage(tab.id,{type:'TTD_FILL',pilgrims:records.pilgrims,accommodations:records.accommodations,groups:records.groups});}
    catch(firstError){
      await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},files:['content/content.js']});
      await new Promise(resolve=>setTimeout(resolve,100));
      r=await chrome.tabs.sendMessage(tab.id,{type:'TTD_FILL',pilgrims:records.pilgrims,accommodations:records.accommodations,groups:records.groups});
    }
    if(!silent)status(r?.message||'Fill operation completed.',!!r?.ok);
    return r;
  }catch(e){
    if(!silent){
      const msg=String(e?.message||e);
      if(/Cannot access contents of url|Cannot access a chrome:\/\/|Extensions gallery|not allowed|Receiving end does not exist/i.test(msg))status('Chrome blocked access to this page. Open the actual TTD form page (not a chrome://, Web Store, PDF, or extension page) and try again.',false);
      else status('Unable to access the current TTD page. Please keep the TTD form page active and try again.',false);
      console.error('TTD Autofill:',e);
    }
    return null;
  }
}
function render(){
  ensureGroups();
  $('#groupTitle').textContent=`${t('groupSection')} (${data.groups.length})`;
  $('#groupList').innerHTML=data.groups.map((g,i)=>`<div class="item group-item ${g.selected?'selected-group':''}" draggable="true" data-type="g" data-id="${g.id}" aria-label="${esc(g.name)}" role="listitem"><div class="item-top"><span class="drag" aria-hidden="true" title="Drag to reorder">☷</span><input type="radio" name="group-radio" class="group-pick" aria-label="${esc(t('selectGroup'))}: ${esc(g.name)}" ${g.selected?'checked':''}><span class="name" dir="auto">${esc(g.name)}</span><button class="secondary small edit" aria-label="Edit ${esc(g.name)}">${t('edit')}</button><button class="secondary small del" aria-label="Delete ${esc(g.name)}">${t('del')}</button></div><div class="meta">${data.pilgrims.filter(p=>p.groupId===g.id).length} pilgrim(s) • ${data.accommodations.filter(a=>a.groupId===g.id).length} accommodation(s)</div></div>`).join('');
  $('#pilgrimTitle').textContent=`Pilgrim Details (${data.pilgrims.length})`;
  $('#accomTitle').textContent=`Accommodation Details (${data.accommodations.length})`;
  $('#pilgrimList').innerHTML=data.pilgrims.map(p=>`<div class="item" draggable="true" data-type="p" data-id="${p.id}" role="listitem"><div class="item-top"><span class="drag" aria-hidden="true" title="Drag to reorder">☷</span><span class="name" dir="auto">${esc(p.name||'Unnamed')}</span><button class="secondary small edit" aria-label="Edit ${esc(p.name||'pilgrim')}" >${t('edit')}</button><button class="secondary small del" aria-label="Delete ${esc(p.name||'pilgrim')}">${t('del')}</button></div><div class="meta">${esc(groupName(p.groupId))} • ${esc(p.age)} • ${esc(p.gender)} • ${esc(p.photoIdType)} • ${esc(p.idProofNumber)}</div></div>`).join('') || `<div class="hint">${t('noPilgrims')}</div>`;
  $('#accomList').innerHTML=data.accommodations.map(a=>`<div class="item" draggable="true" data-type="a" data-id="${a.id}" role="listitem"><div class="item-top"><span class="drag" aria-hidden="true" title="Drag to reorder">☷</span><span class="name" dir="auto">${esc(a.email||'Unnamed profile')}</span><button class="secondary small edit" aria-label="Edit ${esc(a.email||'accommodation')}" >${t('edit')}</button><button class="secondary small del" aria-label="Delete ${esc(a.email||'accommodation')}">${t('del')}</button></div><div class="meta">${esc(groupName(a.groupId))} • ${esc(a.city)} • ${esc(a.state)} • ${esc(a.country)} • ${esc(a.pincode)} • ${esc(a.gotharam)}</div></div>`).join('') || `<div class="hint">${t('noAccom')}</div>`;
  bindItems();save();
}
function reorder(type,id,targetId){const key=type==='g'?'groups':type==='p'?'pilgrims':'accommodations';const arr=data[key],from=arr.findIndex(x=>x.id===id),to=arr.findIndex(x=>x.id===targetId);if(from<0||to<0||from===to)return;const [x]=arr.splice(from,1);arr.splice(to,0,x);save();render()}
function bindItems(){
  document.querySelectorAll('.item[draggable="true"]').forEach(el=>{
    const type=el.dataset.type;
    const delButton=el.querySelector('.del');
    const editButton=el.querySelector('.edit');
    if(type==='g'){
      const checkbox=el.querySelector('.group-pick');
      checkbox.onchange=e=>{
        e.stopPropagation();
        const g=data.groups.find(v=>v.id===el.dataset.id);
        if(!g)return;
        // Radio behaviour: deselect all, then select only this one
        data.groups.forEach(x=>x.selected=false);
        g.selected=true;
        save();
        render();
        // Selection changes only affect local state. Filling happens only when the user clicks Fill Current Page.
      };
      delButton.onclick=e=>{e.preventDefault();e.stopPropagation();deleteGroup(el.dataset.id)};
      editButton.onclick=e=>{e.preventDefault();e.stopPropagation();editGroup(el.dataset.id)};
    }else{
      delButton.onclick=e=>{
        e.preventDefault();e.stopPropagation();
        const key=type==='p'?'pilgrims':'accommodations';
        const obj=data[key].find(x=>x.id===el.dataset.id);
        if(!obj)return;
        if(!confirm(`Delete this ${type==='p'?'pilgrim':'accommodation'} record?`))return;
        const idx=data[key].findIndex(x=>x.id===el.dataset.id);
        if(idx<0)return;
        data[key].splice(idx,1);
        save();
        render();
        status('Record deleted.');
      };
      editButton.onclick=e=>{e.preventDefault();e.stopPropagation();edit(type,el.dataset.id)};
    }
    el.ondragstart=e=>{e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',JSON.stringify({type,id:el.dataset.id}))};
    el.ondragover=e=>{e.preventDefault();e.dataTransfer.dropEffect='move'};
    el.ondrop=e=>{e.preventDefault();e.stopPropagation();try{const d=JSON.parse(e.dataTransfer.getData('text/plain'));if(d.type!==type||d.id===el.dataset.id)return;reorder(type,d.id,el.dataset.id)}catch(_){}};
  });
}
function groupEditor(obj={}){return `<div class="item editor" style="margin-top:10px" id="groupEditor" role="dialog" aria-label="${t('groupDetails')}"><div class="name">${t('groupDetails')}</div><div class="field-grid"><div class="field full"><label for="g_name">${t('groupName')}</label><input id="g_name" maxlength="50" placeholder="Example: Family Group" value="${esc(obj.name)}"></div></div><div class="item-actions"><button id="saveGroup" class="primary small">${t('save')}</button><button id="cancelGroup" class="secondary small">${t('cancel')}</button></div></div>`}
function openUniqueEditor(container,editorId,html,onCancel,onSave){
  const existing=container.querySelector(`[data-editor-id="${editorId}"]`);
  if(existing){
    existing.scrollIntoView({block:'nearest'});
    existing.querySelector('input,select')?.focus();
    return existing;
  }
  // Only one editor can be open in a section at a time. Opening another record
  // collapses/removes the previous editor so the latest requested record is shown.
  container.querySelectorAll('.editor[data-editor-scope]').forEach(editor=>editor.remove());
  const holder=document.createElement('div');
  holder.innerHTML=html;
  const editor=holder.firstElementChild;
  editor.dataset.editorId=editorId;
  editor.dataset.editorScope='single';
  container.append(editor);
  editor.querySelector('[id^="cancel"]')?.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();onCancel(editor)});
  editor.querySelector('[id^="save"]')?.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();onSave(editor)});
  editor.querySelector('input,select')?.focus();
  return editor;
}
function addGroup(){
  const container=$('#groupList');
  const editor=openUniqueEditor(container,'group:new',groupEditor({}),ed=>ed.remove(),ed=>{
    const name=ed.querySelector('#g_name').value.trim();
    if(!/^[A-Za-z0-9][A-Za-z0-9 _-]{0,49}$/.test(name)){status('Please enter a valid group name.',false);return}
    if(data.groups.some(g=>g.name.toLowerCase()===name.toLowerCase())){status('Group name already exists.',false);return}
    data.groups.push({id:uid(),name,selected:false});save();ed.remove();render();status('Group saved.')
  });
  return editor;
}
function editGroup(id){
  const obj=data.groups.find(g=>g.id===id);if(!obj)return;
  const container=$('#groupList');
  return openUniqueEditor(container,`group:${id}`,groupEditor(obj),ed=>ed.remove(),ed=>{
    const name=ed.querySelector('#g_name').value.trim();
    if(!/^[A-Za-z0-9][A-Za-z0-9 _-]{0,49}$/.test(name)){status('Please enter a valid group name.',false);return}
    if(data.groups.some(g=>g.id!==id&&g.name.toLowerCase()===name.toLowerCase())){status('Group name already exists.',false);return}
    obj.name=name;save();ed.remove();render();status('Group updated.')
  });
}
function deleteGroup(id){
  const g=data.groups.find(x=>x.id===id);
  if(!g)return;
  const affectedP=data.pilgrims.filter(x=>x.groupId===id).length;
  const affectedA=data.accommodations.filter(x=>x.groupId===id).length;
  const affected=affectedP+affectedA;
  let action='delete';
  let replacement=data.groups.find(x=>x.id!==id);
  if(affected && replacement){
    action=confirm(`Delete "${g.name}"? ${affected} associated record(s) will be moved to "${replacement.name}".\n\nOK = Delete group and reassign records\nCancel = Keep group`)?'reassign':'cancel';
  }else if(affected && !replacement){
    action=confirm(`Delete the last group "${g.name}"? This will also delete ${affected} associated record(s) because no other group exists.\n\nOK = Delete group and its associated records\nCancel = Keep group`)?'cascade':'cancel';
  }else{
    action=confirm(`Delete group "${g.name}"?`)?'delete':'cancel';
  }
  if(action==='cancel')return;
  if(action==='reassign'){
    data.pilgrims.forEach(x=>{if(x.groupId===id)x.groupId=replacement.id});
    data.accommodations.forEach(x=>{if(x.groupId===id)x.groupId=replacement.id});
  }else if(action==='cascade'){
    data.pilgrims=data.pilgrims.filter(x=>x.groupId!==id);
    data.accommodations=data.accommodations.filter(x=>x.groupId!==id);
  }
  data.groups=data.groups.filter(x=>x.id!==id);
  // If the deleted group was the active one (or no group is selected), select the new top group
  if(data.groups.length && !data.groups.some(g=>g.selected)) data.groups[0].selected=true;
  ensureGroups();
  save();
  render();
  status('Group deleted.');
}
function modalForm(type,obj={}){
  const p=type==='p',title=p?t('pilgrimDetails'):t('accommodationDetails'),firstGroup=data.groups[0]?.id||'',selectedGroup=obj.groupId||firstGroup;
  return `<div class="item editor" style="margin-top:10px" id="editor" role="dialog" aria-label="${esc(title)}"><div class="name">${title}</div><div class="field-grid"><div class="field full"><label for="f_group">${t('groupName')}</label><select id="f_group" aria-label="${t('groupName')}">${groupOptions(selectedGroup)}</select></div>${p?`<div class="field full"><label for="f_name">Name</label><input id="f_name" maxlength="80" placeholder="Example: Ramesh Kumar" value="${esc(obj.name)}"></div><div class="field"><label for="f_age">Age</label><input id="f_age" inputmode="numeric" maxlength="3" placeholder="Example: 35" value="${esc(obj.age)}"></div><div class="field"><label for="f_gender">Gender</label><select id="f_gender"><option>Select</option><option ${obj.gender==='Male'?'selected':''}>Male</option><option ${obj.gender==='Female'?'selected':''}>Female</option><option ${obj.gender==='Transgender'?'selected':''}>Transgender</option></select></div><div class="field"><label for="f_idtype">Photo ID Proof</label><select id="f_idtype"><option>Select</option><option ${obj.photoIdType==='Aadhaar Card'?'selected':''}>Aadhaar Card</option><option ${obj.photoIdType==='Passport'?'selected':''}>Passport</option></select></div><div class="field"><label for="f_idnum">Photo ID Number</label><input id="f_idnum" maxlength="12" placeholder="Example: ABCD12345678" value="${esc(obj.idProofNumber)}"></div>`:`<div class="field full"><label for="f_email">Email Address</label><input id="f_email" placeholder="Example: user@example.com" value="${esc(obj.email)}"></div><div class="field"><label for="f_city">City</label><input id="f_city" placeholder="Example: Chennai" value="${esc(obj.city)}"></div><div class="field"><label for="f_state">State</label><input id="f_state" placeholder="Example: Tamil Nadu" value="${esc(obj.state)}"></div><div class="field"><label for="f_country">Country</label><input id="f_country" placeholder="Example: India" value="${esc(obj.country)}"></div><div class="field"><label for="f_pin">Pincode</label><input id="f_pin" maxlength="6" inputmode="numeric" placeholder="Example: 600001" value="${esc(obj.pincode)}"></div><div class="field"><label for="f_gotharam">Gotharam</label><input id="f_gotharam" placeholder="Example: Bharadwaja" value="${esc(obj.gotharam)}"></div>`}</div><div class="item-actions"><button id="saveEdit" class="primary small">${t('save')}</button><button id="cancelEdit" class="secondary small">${t('cancel')}</button></div></div>`;
}
function edit(type,id){
  const key=type==='p'?'pilgrims':'accommodations',obj=data[key].find(x=>x.id===id);
  if(!obj)return;
  const container=type==='p'?$('#pilgrimList'):$('#accomList');
  return openUniqueEditor(container,`${type}:${id}`,modalForm(type,obj),ed=>ed.remove(),ed=>commit(type,obj,ed,false));
}
function add(type){
  const obj={id:uid(),groupId:data.groups[0]?.id||''};
  const container=type==='p'?$('#pilgrimList'):$('#accomList');
  return openUniqueEditor(container,`${type}:new`,modalForm(type,obj),ed=>ed.remove(),ed=>commit(type,obj,ed,true));
}
function commit(type,obj,e,isNew=false){
  const get=id=>e.querySelector(id)?.value.trim()||'';obj.groupId=get('#f_group');if(!obj.groupId){status('Please select a group.',false);return}
  if(type==='p'){obj.name=get('#f_name');obj.age=get('#f_age');obj.gender=get('#f_gender');obj.photoIdType=get('#f_idtype');obj.idProofNumber=get('#f_idnum');if(!/^[A-Za-z ]+$/.test(obj.name)||!/^[0-9]{1,3}$/.test(obj.age)||obj.gender==='Select'||obj.photoIdType==='Select'||!/^[A-Za-z0-9]+$/.test(obj.idProofNumber)){status('Please enter valid pilgrim details.',false);return}if(isNew)data.pilgrims.push(obj)}
  else{obj.email=get('#f_email');obj.city=get('#f_city');obj.state=get('#f_state');obj.country=get('#f_country');obj.pincode=get('#f_pin');obj.gotharam=get('#f_gotharam');if(!/^\S+@\S+\.\S+$/.test(obj.email)||!obj.city||!/^[A-Za-z ]+$/.test(obj.state)||!/^[A-Za-z ]+$/.test(obj.country)||!/^[0-9]{1,6}$/.test(obj.pincode)||!obj.gotharam){status('Please enter valid accommodation details.',false);return}if(isNew)data.accommodations.push(obj)}
  save();e.remove();render();status(isNew?'Details saved.':'Details updated.')
}
function cleanExportValue(value){return String(value??'').replace(/[\r\n|]/g,' ').trim()}
function exportData(){
  ensureGroups();
  const lines=['Group Name | Name | Age | Gender | Photo ID Proof | Photo Id Number | Email Address | City | State | Country | Pincode | Gotharam |'];
  for(const g of data.groups){
    const pilgrims=data.pilgrims.filter(p=>p.groupId===g.id);
    const accommodations=data.accommodations.filter(a=>a.groupId===g.id);
    const pairedAccommodation=accommodations[0]||{};
    if(pilgrims.length){
      for(const p of pilgrims){
        lines.push([g.name,p.name,p.age,p.gender,p.photoIdType,p.idProofNumber,pairedAccommodation.email,pairedAccommodation.city,pairedAccommodation.state,pairedAccommodation.country,pairedAccommodation.pincode,pairedAccommodation.gotharam].map(cleanExportValue).join(' | ')+' |');
      }
      for(let i=1;i<accommodations.length;i++){
        const a=accommodations[i];
        lines.push([g.name,'','','','','',a.email,a.city,a.state,a.country,a.pincode,a.gotharam].map(cleanExportValue).join(' | ')+' |');
      }
    }else if(accommodations.length){
      for(const a of accommodations){
        lines.push([g.name,'','','','','',a.email,a.city,a.state,a.country,a.pincode,a.gotharam].map(cleanExportValue).join(' | ')+' |');
      }
    }else{
      lines.push([g.name,'','','','','','','','','','',''].map(cleanExportValue).join(' | ')+' |');
    }
  }
  const blob=new Blob([lines.join('\n')+'\n'],{type:'text/plain;charset=utf-8'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');a.href=url;a.download=`TTD_Darasan_Autofill_Data_${new Date().toISOString().slice(0,10)}.txt`;
  document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);status(t('exportDone'));
}
function parseExportText(text){
  const rawLines=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  if(!rawLines.length)throw new Error('The TXT file is empty.');
  const normalizedHeader=rawLines[0].replace(/^\uFEFF/,'').trim();
  const expectedHeader='Group Name | Name | Age | Gender | Photo ID Proof | Photo Id Number | Email Address | City | State | Country | Pincode | Gotharam |';
  if(normalizedHeader.replace(/\s+/g,' ')!==expectedHeader)throw new Error('Invalid TXT header. Please import a TTD Darasan Autofill TXT export.');
  const groupsMap=new Map();
  for(let lineNo=1;lineNo<rawLines.length;lineNo++){
    const line=rawLines[lineNo];
    const parts=line.split('|').map(x=>x.trim());
    if(parts.length<12)continue;
    const values=parts.slice(0,12);
    const [group,name,age,gender,photoIdType,idProofNumber,email,city,state,country,pincode,gotharam]=values;
    if(!group)continue;
    if(!groupsMap.has(group))groupsMap.set(group,{pilgrims:[],accommodations:[]});
    const bucket=groupsMap.get(group);
    if(name||age||gender||photoIdType||idProofNumber){
      const p={name,age,gender,photoIdType,idProofNumber};
      const key=JSON.stringify([name,age,gender,photoIdType,idProofNumber]);
      if(!bucket.pilgrims.some(x=>JSON.stringify([x.name,x.age,x.gender,x.photoIdType,x.idProofNumber])===key))bucket.pilgrims.push(p);
    }
    if(email||city||state||country||pincode||gotharam){
      const a={email,city,state,country,pincode,gotharam};
      const key=JSON.stringify([email,city,state,country,pincode,gotharam]);
      if(!bucket.accommodations.some(x=>JSON.stringify([x.email,x.city,x.state,x.country,x.pincode,x.gotharam])===key))bucket.accommodations.push(a);
    }
  }
  if(!groupsMap.size)throw new Error('No valid data rows were found in the TXT file.');
  return [...groupsMap.entries()];
}
async function importData(){
  const input=document.createElement('input');
  input.type='file';input.accept='.txt,text/plain';
  input.onchange=async()=>{
    const file=input.files?.[0];if(!file)return;
    if(!/\.txt$/i.test(file.name)){status('Import accepts TXT files only.',false);return}
    try{
      const text=await file.text();
      const imported=parseExportText(text);
      let addedGroups=0,addedPilgrims=0,addedAccom=0,updatedPilgrims=0,updatedAccom=0;
      for(const [name,bucket] of imported){
        let g=data.groups.find(x=>x.name.toLowerCase()===name.toLowerCase());
        if(!g){
          g={id:uid(),name,selected:false};
          data.groups.push(g);
          addedGroups++;
        }else if(g.name!==name){
          g.name=name;
        }

        // Upsert Pilgrim Tickets using Group + Name as the stable TXT import identity.
        for(const p of bucket.pilgrims){
          const existing=data.pilgrims.find(x=>x.groupId===g.id && x.name.trim().toLowerCase()===p.name.trim().toLowerCase());
          if(existing){
            Object.assign(existing,{groupId:g.id,name:p.name,age:p.age,gender:p.gender,photoIdType:p.photoIdType,idProofNumber:p.idProofNumber});
            updatedPilgrims++;
          }else{
            data.pilgrims.push({...p,id:uid(),groupId:g.id});
            addedPilgrims++;
          }
        }

        // Upsert Accommodation Details using Group + Email as the stable TXT import identity.
        for(const a of bucket.accommodations){
          const existing=data.accommodations.find(x=>x.groupId===g.id && a.email && x.email.trim().toLowerCase()===a.email.trim().toLowerCase());
          if(existing){
            Object.assign(existing,{groupId:g.id,email:a.email,city:a.city,state:a.state,country:a.country,pincode:a.pincode,gotharam:a.gotharam});
            updatedAccom++;
          }else{
            data.accommodations.push({...a,id:uid(),groupId:g.id});
            addedAccom++;
          }
        }
      }
      ensureGroups();save();render();
      status(`Import completed: ${addedGroups} group(s), ${addedPilgrims} new / ${updatedPilgrims} updated pilgrim record(s), ${addedAccom} new / ${updatedAccom} updated accommodation record(s).`);
    }catch(e){status(e?.message||'Unable to import the selected TXT file.',false)}
  };
  input.click();
}
$('#addGroup').onclick=addGroup;$('#addPilgrim').onclick=()=>add('p');$('#addAccom').onclick=()=>add('a');$('#exportBtn').onclick=exportData;$('#importBtn').onclick=importData;
$('#aboutBtn').onclick=()=>{$('#mainScreen').classList.add('hidden');$('#aboutScreen').classList.remove('hidden')};$('#closeAbout').onclick=()=>{$('#aboutScreen').classList.add('hidden');$('#mainScreen').classList.remove('hidden')};
$('#fillBtn').onclick=async()=>{const records=selectedRecords();if(!records.groups.length){status('Select a Group Name.',false);return}if(!records.pilgrims.length){status('The selected group(s) contain no pilgrim records.',false);return}await fillActivePage(records,false)};
chrome.storage.local.get(DEFAULT,r=>{data={...DEFAULT,...r,groups:Array.isArray(r.groups)?r.groups:[],pilgrims:Array.isArray(r.pilgrims)?r.pilgrims:[],accommodations:Array.isArray(r.accommodations)?r.accommodations:[]};ensureGroups();save();render()});
